# FireworkCommand

A compact Paper 1.21.11 plugin. One command, one class, no config files.

`/firework <player> <amount>` launches `<amount>` staggered, randomly colored,
randomly shaped fireworks around that player (max 50 per use).

## Build it (needs internet + JDK 21 + Maven)
```
mvn package
```
The finished plugin appears at `target/FireworkCommand.jar`. Drop it into
your server's `plugins/` folder and restart (or `/reload`, if you're brave).

## Or build it with GitHub Actions (no local Java/Maven needed)
1. Create a new GitHub repository and upload this whole folder to it
   (GitHub web UI: "Add file" -> "Upload files" works fine, no git required).
2. Open the repo's **Actions** tab - a workflow starts automatically and
   compiles the jar for you.
3. Click into the finished run and download the `FireworkCommand` artifact -
   that's your `FireworkCommand.jar`.

## In-game usage
```
/firework Notch 10
```
Fires 10 fireworks at Notch, launched one after another for a proper "show"
effect. Console can run it too, targeting any online player.

- Permission node: `fireworkcommand.use` (defaults to server operators only -
  edit `default: op` to `default: true` in `plugin.yml` before building if
  you want everyone to be able to use it).
- Tab-completion suggests online player names and a few sample amounts.
