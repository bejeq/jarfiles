package com.fireworkcommand.plugin;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

/**
 * FireworkCommand
 *
 * Adds a single command: /firework <player> <amount>
 * Launches <amount> randomly colored, randomly shaped fireworks in a short
 * staggered show around the target player.
 */
public final class FireworkCommandPlugin extends JavaPlugin implements CommandExecutor, TabCompleter {

    /** Hard cap so nobody can accidentally (or deliberately) lag the server with a huge amount. */
    private static final int MAX_FIREWORKS = 50;

    /** Ticks between each firework launch, so a big batch reads as a "show" rather than one blob. */
    private static final long TICKS_BETWEEN_LAUNCHES = 4L;

    /** Vivid color palette to pick from - primary colors and fade colors are both drawn from this. */
    private static final List<Color> PALETTE = Arrays.asList(
            Color.RED, Color.ORANGE, Color.YELLOW, Color.LIME, Color.GREEN,
            Color.AQUA, Color.BLUE, Color.PURPLE, Color.FUCHSIA, Color.WHITE
    );

    private static final FireworkEffect.Type[] TYPES = FireworkEffect.Type.values();

    private final Random random = new Random();

    @Override
    public void onEnable() {
        PluginCommand command = getCommand("firework");
        if (command != null) {
            command.setExecutor(this);
            command.setTabCompleter(this);
        }
        getLogger().info("FireworkCommand enabled! Use /firework <player> <amount>");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length != 2) {
            sender.sendMessage(ChatColor.RED + "Usage: /firework <player> <amount>");
            return true;
        }

        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            target = Bukkit.getPlayer(args[0]);
        }
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Player '" + args[0] + "' is not online.");
            return true;
        }

        final int amount;
        try {
            int parsed = Integer.parseInt(args[1]);
            if (parsed < 1) {
                sender.sendMessage(ChatColor.RED + "Amount must be at least 1.");
                return true;
            }
            if (parsed > MAX_FIREWORKS) {
                sender.sendMessage(ChatColor.YELLOW + "Amount capped at " + MAX_FIREWORKS + " to keep the server running smoothly.");
                parsed = MAX_FIREWORKS;
            }
            amount = parsed;
        } catch (NumberFormatException e) {
            sender.sendMessage(ChatColor.RED + "Amount must be a whole number.");
            return true;
        }

        launchFireworks(target, amount);

        sender.sendMessage(ChatColor.GREEN + "Launched " + amount + " firework(s) at " + target.getName() + "!");
        if (!sender.getName().equalsIgnoreCase(target.getName())) {
            target.sendMessage(ChatColor.LIGHT_PURPLE + sender.getName() + " just launched fireworks for you!");
        }
        return true;
    }

    /** Schedules `amount` fireworks, staggered a few ticks apart so they read as a show. */
    private void launchFireworks(Player target, int amount) {
        for (int i = 0; i < amount; i++) {
            long delay = i * TICKS_BETWEEN_LAUNCHES;
            new BukkitRunnable() {
                @Override
                public void run() {
                    spawnRandomFirework(target);
                }
            }.runTaskLater(FireworkCommandPlugin.this, delay);
        }
    }

    /** Spawns one firework with a random type/color/fade near the target's current location. */
    private void spawnRandomFirework(Player target) {
        if (!target.isOnline()) {
            return; // player logged off mid-show
        }
        World world = target.getWorld();
        Location base = target.getLocation();

        // Scatter fireworks a little around the player instead of stacking them in one spot.
        double dx = (random.nextDouble() - 0.5) * 3.0;
        double dz = (random.nextDouble() - 0.5) * 3.0;
        Location spawnLoc = base.clone().add(dx, 0.5, dz);

        Firework firework = world.spawn(spawnLoc, Firework.class);
        FireworkMeta meta = firework.getFireworkMeta();

        FireworkEffect effect = FireworkEffect.builder()
                .with(TYPES[random.nextInt(TYPES.length)])
                .withColor(randomColors(1 + random.nextInt(3)))
                .withFade(randomColors(random.nextInt(3)))
                .flicker(random.nextBoolean())
                .trail(random.nextBoolean())
                .build();

        meta.addEffect(effect);
        meta.setPower(1 + random.nextInt(2));
        firework.setFireworkMeta(meta);
    }

    private List<Color> randomColors(int count) {
        List<Color> colors = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            colors.add(PALETTE.get(random.nextInt(PALETTE.size())));
        }
        return colors;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            String partial = args[0].toLowerCase();
            return Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(name -> name.toLowerCase().startsWith(partial))
                    .collect(Collectors.toList());
        }
        if (args.length == 2) {
            return Arrays.asList("1", "5", "10", "20");
        }
        return new ArrayList<>();
    }
}
